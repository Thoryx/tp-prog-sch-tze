/////////////////////////////////////////////////////////////////////////////
// Name:        funcmacro_procctrl.h
// Purpose:     Process Control function and macro group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_funcmacro_procctrl Process Control
@ingroup group_funcmacro

The functions in this section are used to launch or terminate the other
processes.

*/

