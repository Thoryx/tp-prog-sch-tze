/////////////////////////////////////////////////////////////////////////////
// Name:        funcmacro.h
// Purpose:     Main function and macro group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_funcmacro Functions and Macros by Category

This group defines all major function and macro groups.

*/

